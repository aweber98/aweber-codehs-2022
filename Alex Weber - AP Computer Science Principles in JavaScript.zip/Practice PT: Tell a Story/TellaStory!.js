/*
 * This program tells a graphical story in 4 frames.
 */

/* 
 * Draws the first scene on the canvas and outputs the first
 * section of text for the story.
 */
function drawScene1(){
    rectangle2();
    rectangle3();
    drawCircle();
    circle2();
    circle3();
    sun();
    println("Red circle is taking a stroll");
}

/* 
 * Draws the second scene on the canvas and outputs the second
 * section of text for the story.
 */
function drawScene2(){
    rectangle2();
    rectangle3();
    drawCircle();
    circle2();
    circle3();
    newOval();
    circle5();
    circle4();
    text();
    println("Blue oval bumps into red circle");
}

/* 
 * Draws the third scene on the canvas and outputs the third
 * section of text for the story.
 */
function drawScene3(){
    rectangle2();
    rectangle3();
    drawCircle();
    circle2();
    circle3();
    newOval();
    circle5();
    circle4();
    text3();
    println("Red circle and blue oval decide to become friends");
}

/* 
 * Draws the fourth scene on the canvas and outputs the fourth
 * section of text for the story.
 */
function drawScene4(){
    rectangle2();
    rectangle3();
    drawCircle();
    circle2();
    circle3();
    newOval();
    circle5();
    circle4();
    text2();
    println("Blue oval decides it's time to head out");
}

function drawScene5(){
    rectangle2();
    rectangle3();
    drawCircle();
    circle2();
    circle3();
    newOval();
    circle5();
    circle4();
    text4();
    println("The end. (Be nice to others)");
}

/**********************************************************
 * This is set up code that makes the story advance from
 * scene to scene. Feel free to check out this code and
 * learn how it works!
 * But be careful! If you modify this code the story might
 * not work anymore.
 **********************************************************/

var sceneCounter = 0;
function start() {
    
    var welcome = new Text("Click to Begin!");
    
    welcome.setPosition(
        getWidth() / 2 - welcome.getWidth() / 2,
        getHeight() / 2
    );
    
    add(welcome);
    
    // Call the drawNextScene function every time the mouse is clicked
    mouseClickMethod(drawNextScene);
}

/*
 * When this function is called the next scene is drawn.
 */
function drawNextScene(){
    sceneCounter++;
    
    if(sceneCounter == 1) {
        drawScene1();
    } else if (sceneCounter == 2) {
        drawScene2();
    } else if (sceneCounter == 3) {
        drawScene3();
    } else if (sceneCounter == 4) {
        drawScene4();
    } else {
        drawScene5();
    }
}

function drawCircle(){
    var circle = new Circle(50);
    circle.setPosition(100, 200);
    circle.setColor(Color.red);
    add(circle);
}

function rectangle2(){
    var rect = new Rectangle(1000, 270);
    rect.setPosition(0, 0);
    rect.setColor(Color.cyan);
    add(rect);
}

function rectangle3(){
    var rect = new Rectangle(650, 250);
    rect.setPosition(0, 250);
    rect.setColor(Color.green);
    add(rect);
}

function circle2(){
    var circle = new Circle(5);
    circle.setPosition(125, 190);
    circle.setColor(Color.black);
    add(circle);
}

function circle3(){
    var circle = new Circle(5);
    circle.setPosition(80, 190);
    circle.setColor(Color.black);
    add(circle);
}

function newOval(){
    var oval = new Oval(100, 150);
    oval.setPosition(200, 190);
    oval.setColor(Color.blue);
    add(oval);
    
}

function circle4(){
    var circle = new Circle(5);
    circle.setPosition(180, 160);
    circle.setColor(Color.black);
    add(circle);
}

function circle5(){
    var circle = new Circle(5);
    circle.setPosition(220, 160);
    circle.setColor(Color.black);
    add(circle);
}

function text(){
    var txt = new Text("Sorry, I wasn't paying attention", "15pt Arial");
    txt.setPosition(100, 100);
    txt.setColor(Color.black);
    add(txt);
}

function text2(){
    var txt = new Text("Well gotta go, Bye!", "15pt Arial");
    txt.setPosition(120, 100);
    txt.setColor(Color.black);
    add(txt);
}


function text3(){
    var txt = new Text("It's alright, let's be friends.", "15pt Arial");
    txt.setPosition(0, 110);
    txt.setColor(Color.black);
    add(txt);
}

function text4(){
    var txt = new Text("The End.", "20pt Arial");
    txt.setPosition(80, 100);
    txt.setColor(Color.black);
    add(txt);
}

function sun(){
    var center = new Circle(75);
    center.setPosition(400,30);
    center.setColor(Color.yellow);
    add(center);
}