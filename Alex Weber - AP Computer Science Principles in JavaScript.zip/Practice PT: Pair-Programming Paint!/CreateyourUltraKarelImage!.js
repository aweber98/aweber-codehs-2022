// Run before editing!

/* This program will have Karel make Pikachu */
function start(){
    makeOutline();
    colorIn();
}


/* This function will have Karel make the outline of Pikachu */
function makeOutline(){
    /* This function has been completed */
       for(var i = 0; i < 5; i++){
        move();
    }
    for(var i = 0; i < 2; i++){
        paint(Color.black);
        move();
    }
    paint(Color.black);
    turnLeft();
    move();
    turnRight();
    paintLine();
    turnAround();
    move();
    turnLeft();
    move();
    turnLeft();
    for(var i = 0; i < 3; i++){
        paint(Color.black);
        move();
    }
    turnLeft();
    move();
    paint(Color.black);
    move();
    turnLeft();
    move();
    paint(Color.black);
    move();
    paint(Color.black);
    turnAround();
    move();
    turnLeft();
    move();
    paint(Color.black);
    next();
    for(var i = 0; i < 3; i++){
        paint(Color.black);
        move();
    }
    paint(Color.black);
    turnLeft();
    move();
    paint(Color.black);
    turnRight();
    for(var i = 0; i < 3; i++){
        paint(Color.black);
        move();
    }
    paint(Color.black);
    turnRight();
    move();
    paint(Color.black);
    turnLeft();
    for(var i = 0; i < 2; i++){
        paint(Color.black);
        move();
    }
    paint(Color.black);
    turnLeft();
    move();
    turnRight();
    for(var i = 0; i < 6; i++){
        paint(Color.black);
        move();
    }
    paint(Color.black);
    turnRight();
    move();
    turnLeft();
    for(var i = 0; i < 5; i++){
        paint(Color.black);
        move();
    }
    paint(Color.black);
    turnLeft();
    move();
    paint(Color.black);
    turnLeft();
    next1();
    paint(Color.black);
    turnLeft();
    move();
    paint(Color.black);
    next1();
    paint(Color.black);
    turnLeft();
    move();
    paint(Color.black);
    turnRight();
    move();
    paint(Color.black);
    turnLeft();
    move();
    turnRight();
    paintLine();
    turnAround();
    move();
    move();
    move();
    move();
    turnLeft();
    move();
    paint(Color.black);
    next2();
    for(var i = 0; i < 5; i++){
        paint(Color.black);
        next();
    }
    turnLeft();
    move();
    move();
    for(var i = 0; i < 4; i++){
        paint(Color.black);
        move();
    }
    paint(Color.black);
    turnLeft();
    for(var i = 0; i < 4; i++){
        move();
        paint(Color.black);
    }
    turnAround();
    for(var i = 0; i < 4; i++){
        move();
    }
    for(var i = 0; i < 2; i++){
        paint(Color.black);
        move();
    }
    paint(Color.black);
    for(var i = 0; i < 2; i++){
        turnLeft();
        move();
        paint(Color.black);
    }
    turnRight();
    move();
    paint(Color.black)
    turnLeft();
    move();
    paint(Color.black);
    next1();
    paint(Color.black);
    turnLeft();
    move();
    paint(Color.black);
    turnRight();
    for(var i = 0; i < 4; i++){
        paint(Color.black);
        move();
    }
    paint(Color.black);
    turnRight();
    move();
    paint(Color.black);
    turnLeft();
    for(var i = 0; i < 2; i++){
        paint(Color.black);
        move();
    }
    paint(Color.black);
    next3();
    for(var i = 0; i < 3; i++){
        paint(Color.black);
        move();
    }
    paint(Color.black);
    turnRight();
    move();
    turnLeft();
    for(var i = 0; i < 4; i++){
        paint(Color.black);
        move();
    }
    paint(Color.black);
    turnLeft();
    move();
    paint(Color.black);
    turnRight();
    move();
    paint(Color.black);
    turnLeft();
    move();
    paint(Color.black);
    turnAround();
    move();
    move();
    turnLeft();
    move();
    paint(Color.black);
    
    /* This function has been completed */
}


/* This function will have Karel color in Pikachu */
function colorIn(){
    /* This function has been completed */
    turnLeft();
    move();
    paint(Color.yellow);
    move();
    paint(Color.yellow);
    next3();
    move();
    for(var i = 0; i < 3; i++){
        paint(Color.yellow);
        move();
    }
    
    for(var i = 0; i < 3; i++){
        paint(Color.black);
        move();
    }
    
    for(var i = 0; i < 3; i++){
        paint(Color.yellow);
        move();
    }
    turnRight();
    move();
    paint(Color.yellow);
    turnLeft();
    move();
    paint(Color.yellow);
    turnLeft();
    move();
    move();
    turnLeft();
    move();
    for(var i = 0; i < 11; i++){
        paint(Color.yellow);
        move();
    }
    turnRight();
    move();
    turnRight();
    paint(Color.yellow);
    move();
    paint(Color.black);
    move();
    for(var i = 0; i < 9; i++){
        paint(Color.yellow);
        move();
    }
    paint(Color.black);
    move();
    paint(Color.yellow);
    turnLeft();
    move();
    turnLeft();
    for(var i = 0; i < 2; i++){
        paint(Color.yellow);
        move();
    }
    paint(Color.black);
    move();
    for(var i = 0; i < 7; i++){
        paint(Color.yellow);
        move();
    }
    paint(Color.black);
    move();
    for(var i = 0; i < 2; i++){
        paint(Color.yellow);
        move();
    }
    turnRight();
    move();
    turnRight();
    move();
    for(var i = 0; i < 13; i++){
        paint(Color.yellow);
        move();
    }
    turnLeft();
    move();
    turnLeft();
    move();
    move();
    for(var i = 0; i < 11; i++){
        paint(Color.yellow);
        move();
    }
    turnRight();
    move();
    turnRight();
    move();
    for(var i = 0; i < 11; i++){
        paint(Color.yellow);
        move();
    }
    turnLeft();
    move();
    turnLeft();
    move();
    paint(Color.black);
    move();
    paint(Color.red);
    move();
    for(var i = 0; i < 3; i++){
        paint(Color.yellow);
        move();
    }
    paint(Color.black);
    move();
    for(var i = 0; i < 3; i++){
        paint(Color.yellow);
        move();
    }
    paint(Color.red);
    move();
    paint(Color.black);
    turnRight();
    move();
    turnRight();
    for(var i = 0; i < 2; i++){
        paint(Color.red);
        move();
    }
    for(var i = 0; i < 7; i++){
        paint(Color.yellow);
        move();
    }
    for(var i = 0; i < 2; i++){
        paint(Color.red);
        move();
    }
    turnLeft();
    move();
    turnLeft();
    paint(Color.yellow);
    move();
    paint(Color.red);
    move();
    for(var i = 0; i < 4; i++){
        paint(Color.yellow);
        move();
    }
    paint(Color.black);
    move();
    for(var i = 0; i < 4; i++){
        paint(Color.yellow);
        move();
    }
    paint(Color.red);
    move();
    paint(Color.yellow);
    turnRight();
    move();
    turnRight();
    move();
    paint(Color.yellow);
    move();
    for(var i = 0; i < 2; i++){
        paint(Color.black);
        move();
    }
    for(var i = 0; i < 5; i++){
        paint(Color.yellow);
        move();
    }
    for(var i = 0; i < 2; i++){
        paint(Color.black);
        move();
    }
    paint(Color.yellow);
    turnLeft();
    move();
    turnLeft();
    paint(Color.yellow);
    move();
    paint(Color.white);
    move();
    paint(Color.black);
    move();
    for(var i = 0; i < 5; i++){
        paint(Color.yellow);
        move();
    }
    paint(Color.white);
    move();
    paint(Color.black);
    move();
    paint(Color.yellow);
    move();
    turnRight();
    move();
    turnRight();
    move();
    for(var i = 0; i < 11; i++){
        paint(Color.yellow);
        move();
    }
    turnLeft();
    move();
    turnLeft();
    move();
    paint(Color.black);
    move();
    for(var i = 0; i < 9; i++){
        paint(Color.yellow);
        move();
    }
    paint(Color.black);
    turnRight();
    move();
    turnRight();
    for(var i = 0; i < 11; i++){
        paint(Color.yellow);
        move();
    }
    turnLeft();
    move();
    turnLeft();
    move();
    for(var i = 0; i < 13; i++){
        paint(Color.yellow);
        move();
    }
    turnRight();
    move();
    turnRight();
    for(var i = 0; i < 3; i++){
        paint(Color.yellow);
        move();
    }
    for(var i = 0; i < 9; i++){
        move();
    }
    for(var i = 0; i < 2; i++){
        paint(Color.yellow);
        move();
    }
    for(var i = 0; i < 2; i++){
        turnLeft();
        move();
        paint(Color.yellow);
    }
    turnRight();
    move();
    paint(Color.yellow);
    turnRight();
    move();
    paint(Color.black);
    turnLeft();
    move();
    for(var i = 0; i < 2; i++){
        paint(Color.black);
        move();
    }
    turnLeft();
    for(var i = 0; i < 13; i++){
        move();
    }
    paint(Color.yellow);
    turnLeft();
    move();
    for(var i = 0; i < 3; i++){
        paint(Color.yellow);
        move();
    }
    turnLeft();
    move();
    turnLeft();
    move();
    for(var i = 0; i < 3; i++){
        paint(Color.yellow);
        move();
    }
    turnRight();
    move();
    turnRight();
    move();
    move();
    for(var i = 0; i < 2; i++){
        paint(Color.yellow);
        move();
    }
    turnLeft();
    move();
    turnLeft();
    move();
    paint(Color.yellow);
    turnRight();
    move();
    turnRight();
    move();
    paint(Color.yellow);
}


/* This function will have Karel paint a straight black line 9
* long */
function paintLine(){
    for(var i = 0; i < 9; i++){
        paint(Color.black);
        move();
    }
}

/* The "next" functions are just for moving Karel to the next
* diagonal space, depending where he is suposed to go and where
* he is facing */
function next(){
    turnRight();
    move();
    turnLeft();
    move();
}
function next1(){
    move();
    turnRight();
    move();
}
function next2(){
    move();
    turnLeft();
    move();
}
function next3(){
    turnLeft();
    move();
    turnRight();
}