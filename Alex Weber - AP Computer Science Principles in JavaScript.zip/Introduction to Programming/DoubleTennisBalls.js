    /* Regardless of how many balls are there
    /* Karel will double them.
    */
    function start() {
        move();
        takeOnePutTwo();
        moveAllBallsBack();
        goBackToOrigin();
        
    }
    function takeOnePutTwo() {
        while(ballsPresent()) {
            takeBall();
            putTwo();
            moveBack();
        }
    }
    function putTwo() {
        move();
        putBall();
        putBall();
    }
    function moveBack() {
        turnAround();
        move();
        turnAround();
    }
    function moveAllBallsBack() {
        move();
        while(ballsPresent()) {
            takeBall();
            turnAround();
            move();
            putBall();
            turnAround();
            move();
        }
    }
    function goBackToOrigin() {
        turnAround();
        move();
        move();
        turnAround();
    }