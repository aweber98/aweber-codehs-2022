function start(){
    lineOne();
    turnLeft();
    lineTwo();
    turnRight();
    lineThree();
    turnLeft();
    lineFour();
    turnRight();
    lineFive();
    turnLeft();
    lineSix();
    turnRight();
    lineSeven();
    turnLeft();
    lineEight();
    goHome();
    
}

function lineOne(){
    for(var i = 0; i < 3; i++){
        paint(Color.black);
        move();
        paint(Color.red);
        move();
    }
    paint(Color.black);
    move();
    paint(Color.red);
    turnLeft();
    move();
}

function lineTwo(){
    for(var i = 0; i < 3; i++){
        paint(Color.black);
        move();
        paint(Color.red);
        move();
    }
    paint(Color.black);
    move();
    paint(Color.red);
    turnRight();
    move();
}

function lineThree(){
    for(var i = 0; i < 3; i++){
        paint(Color.black);
        move();
        paint(Color.red);
        move();
    }
    paint(Color.black);
    move();
    paint(Color.red);
    turnLeft();
    move();
}

function lineFour(){
    for(var i = 0; i < 3; i++){
        paint(Color.black);
        move();
        paint(Color.red);
        move();
    }
    paint(Color.black);
    move();
    paint(Color.red);
    turnRight();
    move();
}

function lineFive(){
    for(var i = 0; i < 3; i++){
        paint(Color.black);
        move();
        paint(Color.red);
        move();
    }
    paint(Color.black);
    move();
    paint(Color.red);
    turnLeft();
    move();
}

function lineSix(){
    for(var i = 0; i < 3; i++){
        paint(Color.black);
        move();
        paint(Color.red);
        move();
    }
    paint(Color.black);
    move();
    paint(Color.red);
    turnRight();
    move();
}

function lineSeven(){
    for(var i = 0; i < 3; i++){
        paint(Color.black);
        move();
        paint(Color.red);
        move();
    }
    paint(Color.black);
    move();
    paint(Color.red);
    turnLeft();
    move();
}

function lineEight(){
    for(var i = 0; i < 3; i++){
        paint(Color.black);
        move();
        paint(Color.red);
        move();
    }
    paint(Color.black);
    move();
    paint(Color.red);
}

function goHome(){
    turnLeft();
    
    for (var i = 0; i < 7; i++){
        move();
    }
    
    turnLeft();
}