function start() {
    goToBall();
    takeBall();
    goHome();
    putBall();
}

/* this function will have karel go to the ball*/
function goToBall(){
    turnLeft();
    for(var i = 0; i < 4; i++){
        move();
    }
    turnRight();
    move();
    move();
}

/* this function will have karel return to start*/
function goHome(){
    turnAround();
    move();
    move();
    turnLeft();
    for(var i = 0; i < 4; i++){
        move();
    }
    turnLeft();
}