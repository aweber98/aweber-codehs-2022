/* This program draws a big tower from Karel's starting spot */
function start(){
    turnNorth();
    buildTower();
}

// This function has karel face north, no matter what direction
// karel starts facing.
function turnNorth(){
    if(facingSouth()){
        turnLeft();
        turnLeft();
    }
    if(facingEast()){
        turnLeft();
    }
    if(facingWest()){
        turnRight();
    }
        
}

// This function builds a tower all the way to the top of the world.
function buildTower(){
    while(frontIsClear()){
        putBall();
        move();
        
    }
    if(noBallsPresent()){
        putBall();
    }
}

function turnRight(){
    turnLeft();
    turnLeft();
    turnLeft();
}