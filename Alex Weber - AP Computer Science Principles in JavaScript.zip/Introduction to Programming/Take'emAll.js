function start(){
    move();
    for(var i = 0; i < 100; i++){
        takeBall();
    }
    move();
}