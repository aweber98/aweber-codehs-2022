move();
putBall();
turnLeft();

move();
putBall();
move();
putBall();
move();
turnLeft();
turnLeft();
turnLeft();