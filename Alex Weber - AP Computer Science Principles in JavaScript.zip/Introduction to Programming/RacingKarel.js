/* This program will have Karel run around the racetrack
 * 8 times. */
function start() {
    runSide();
    putBalls();
    turnLeft();
    runSide();
    putBalls();
    turnLeft();
    runSide();
    putBalls();
    turnLeft();
    runSide();
    putBalls();
    turnLeft();
}

/* this function will have karel run one side */
function runSide(){
    while(frontIsClear()){
        move();
    }
    
    
}

/* this function will have karel put 8 balls*/
function putBalls(){
    for(var i = 0; i < 8; i++){
        putBall();
    }
}