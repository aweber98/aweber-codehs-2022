// Use the dropdown in the editor to change worlds 
// Your code should work correctly in each world

function start(){
	// Write your code here
	if (facingSouth()){
	    turnLeft();
	}else{
	    turnRight();
	    turnRight();
	}
}