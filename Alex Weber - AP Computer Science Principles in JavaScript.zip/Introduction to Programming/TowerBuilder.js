/* in this program karel will build a tower so long as he is not facing north.
* if he runs into a wall, he will turn North and stop building towers,
* then, he will turn back to facing East*/
function start() {
    while(notFacingNorth()){
        buildTower();
        if(frontIsClear()){
            move();
            
        }
        
        if(frontIsClear()){
            move();
        }else{
            turnLeft();
        }
    
        
    }
    turnRight();
}
/* this function will have karel build a tower */
function buildTower(){
    putBall();
    turnLeft();
    move();
    putBall();
    move();
    putBall();
    turnAround();
    move();
    move();
    turnLeft();
    
}

/* this program was definitely a challenge to write */