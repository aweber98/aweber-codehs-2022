move();
move();
turnLeft();
turnLeft();
turnLeft();
turnLeft();