function start(){
    // Start here   
    moveToWall();
    decorate();
    turnRight();
}

function moveToWall(){
    while (frontIsClear()){
        move();
    }
    turnLeft();
}

function decorate(){
    while(notFacingWest()){
        if (rightIsBlocked()){
            putBall();
        }
        if (frontIsClear()){
            move();
        }else{
            turnLeft();
        }   
    }
    
}