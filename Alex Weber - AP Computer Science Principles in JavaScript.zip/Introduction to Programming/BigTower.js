/* This program draws a big tower from Karel's starting spot */
function start(){
	faceNorth();
	while(frontIsClear()){
	    buildTower();
	}
	if(frontIsBlocked()){
	    /*Makes sure Karel will stop at the wall*/
	    putBall();
	}
}
function buildTower(){
    /*Karel will build a tower*/
    putBall();
    move();
}
function faceNorth(){
    /*Makes Karel face North*/
    if(facingSouth()){
	    turnAround();
	}
	if(facingWest()){
	    turnRight();
	}
	if(facingEast()){
	    turnLeft();
	}
}