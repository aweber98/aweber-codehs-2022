function start(){
    move();
    makePancakes();
    move();
    move();
    makePancakes();
    move();
    move();
    makePancakes();
    move();
}
function makePancakes(){
    putBall();
    putBall();
    putBall();
}