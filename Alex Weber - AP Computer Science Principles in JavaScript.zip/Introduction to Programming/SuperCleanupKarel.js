function start(){
    cleanAvenue();
    while(frontIsClear()){
        cleanAvenue();
    }
    cleanAvenue();
}

/* This function will have Karel clean all avenues*/
function cleanAvenue(){
    if(ballsPresent()){
        takeBall();
    }
    turnLeft();
    while(frontIsClear()){
        move();
        if(ballsPresent()){
            takeBall();
        }
        
    }
    
    turnAround();
    while(frontIsClear()){
        move();
        if(ballsPresent()){
            takeBall();
        }
    }
    if(leftIsClear()){
        turnLeft();
    }
    if(frontIsClear()){
        move();
    }
}