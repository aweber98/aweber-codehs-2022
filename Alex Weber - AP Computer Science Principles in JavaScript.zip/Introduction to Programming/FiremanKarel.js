turnRight();
function turnRight(){
    turnLeft();
    turnLeft();
    turnLeft();
}
move();
move();
move();
turnLeft();