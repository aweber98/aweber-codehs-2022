function start(){
	// Write your code here
	for(var i = 0; i < 5; i++){
	    move();
	    move();
	    jumpHurdle();
	    
	}
}
function jumpHurdle(){
    turnLeft();
	move();
    turnRight();
    move();
    turnRight();
    move();
    turnLeft();   
}