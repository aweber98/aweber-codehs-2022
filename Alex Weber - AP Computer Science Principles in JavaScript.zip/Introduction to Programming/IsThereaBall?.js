// Use the dropdown in the editor to change worlds 
// Your code should work correctly in each world

// Karel should put a ball on the first spot
// if there isn't one already there and then move.
function start() {
	if (ballsPresent()) {
	    move();
	}else{
	    putBall();
	    move();
	}
}