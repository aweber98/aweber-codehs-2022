turnLeft();
makeSide();
turnRight();
makeRoof();
turnRight();
makeSide();
turnRight();
move();
move();
move();
turnLeft();
turnLeft();

function makeRoof(){
    move();
    putBall();
    move();
    putBall();
    move();
    putBall();
}

function turnRight(){
    turnLeft();
    turnLeft();
    turnLeft();
}


function makeSide(){
    move();
    putBall();
    move();
    putBall();
    move();
    putBall();
}

function goHome(){
    turnRight();
    move();
    move();
    move();
    turnLeft();
    turnLeft();
}