putBall();
move();
turnRight();
function turnRight(){
    turnLeft();
    turnLeft();
    turnLeft();
}
move();
putBall();
turnLeft();
move();
turnRight();
move();
putBall();
turnLeft();