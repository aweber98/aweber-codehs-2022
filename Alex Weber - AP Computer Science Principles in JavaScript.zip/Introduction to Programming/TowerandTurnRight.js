move();
turnLeft();
putBall();
move();
putBall();
move();
putBall();
move();
turnRight();

function turnRight(){
	turnLeft();
	turnLeft();
	turnLeft();
}