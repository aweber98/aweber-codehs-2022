function start(){
	move();
	buildTower();
	returnToGround();
	move();
	buildTower();
	move();
	turnRight();
}
function buildTower(){
    putBall();
    turnLeft();
    move();
    putBall();
    move();
    putBall();
}
function turnRight(){
    turnLeft();
    turnLeft();
    turnLeft();
}
function returnToGround(){
    turnRight();
    move();
    turnRight();
    move();
    move();
    turnLeft();
}