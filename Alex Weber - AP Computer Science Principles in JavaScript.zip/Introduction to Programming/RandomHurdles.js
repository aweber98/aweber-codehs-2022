function start(){
    while(facingEast()){
        if(frontIsBlocked()){
            jumpHurdle();
        }else{
            runTrack();
        }
    }
    if(facingSouth()){
        turnLeft();
    }
}

function runTrack(){
    while(frontIsClear()){
        move();
    }
}

function jumpHurdle(){
    turnLeft();
    move();
    turnRight();
    if(frontIsClear()){
        move();
        turnRight();
        move();
        turnLeft();
    }else{
        turnRight();
        move();
    }
}