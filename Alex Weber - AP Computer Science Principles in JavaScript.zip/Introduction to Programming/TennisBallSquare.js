/* Tennis Ball Square
 * This program has Karel place a square of tennis balls
 * and return to his starting point.
 */
putBall();
move();
turnLeft();

putBall();
move();
turnLeft();

putBall();
move();
turnLeft();

putBall();
move();
turnLeft();