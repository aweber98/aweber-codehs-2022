for(var i = 0; i < 70; i++){
	putBall();
}

move();