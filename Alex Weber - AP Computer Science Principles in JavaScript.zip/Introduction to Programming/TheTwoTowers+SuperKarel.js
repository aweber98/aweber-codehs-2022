function start(){
	// Write your code here
	move();
	buildTower();
	move();
	turnRight();
	move();
	move();
	turnLeft();
	move();
	buildTower();
	turnLeft();
	move();
	turnRight();
}

function buildTower(){
    turnLeft();
    putBall();
    move();
    putBall();
    move();
    putBall();
    turnRight();
}