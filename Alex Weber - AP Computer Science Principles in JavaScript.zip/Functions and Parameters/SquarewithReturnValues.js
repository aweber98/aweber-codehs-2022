function start(){
	var y = square(5);
	println(y);
}

function square(x){
    var squaredX = x*x;
    return(squaredX);
}