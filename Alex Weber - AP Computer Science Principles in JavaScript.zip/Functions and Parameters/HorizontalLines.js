function start(){
	horizontalLine(100, 200);
	horizontalLine(200, 100);   
    horizontalLine(300, 20);
}

function horizontalLine (y, x){
    var line = new Line(0, y, x, y);
    add(line);
}