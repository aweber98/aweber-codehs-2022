function start(){
	var num = readInt("Enter a number to triple: ");
	triple(num);
}

function triple(x){
    var tripleX = 3 * x;
    println("Result: " + tripleX);
}