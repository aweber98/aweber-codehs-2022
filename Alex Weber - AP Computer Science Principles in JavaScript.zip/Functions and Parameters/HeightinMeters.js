var INCHES_TO_CM = 2.54;
var CM_TO_METERS = 0.01;
var FEET_TO_INCHES = 12;

function start(){
    var foot = readInt("How tall are you? (feet): ");
    var inches = readInt("How tall are you? (inches): ");
    println("Height: " + foot + ", " + inches);
	convertHeightToMeters(foot, inches);
}

function convertHeightToMeters(first, second){
    var findInches = (first * 12) + second;
    var inchesToCm = findInches * 2.54;
    var meters = inchesToCm * 0.01;
    println("In meters: " + meters);
}