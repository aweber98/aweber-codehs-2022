var LIGHT_RADIUS = 35;
var STOPLIGHT_WIDTH = 120;
var STOPLIGHT_HEIGHT = 350;
var BUFFER = 100;
var GRAY_COLOR = "#737071";

function start(){
	stopLight();
}

function stopLight(){
     var rect = new Rectangle(STOPLIGHT_WIDTH, STOPLIGHT_HEIGHT);
    rect.setColor(GRAY_COLOR);
    var x = getWidth() / 2;
    var y = getHeight() / 2;
    var topX = x - STOPLIGHT_WIDTH / 2;
    var topY = y - STOPLIGHT_HEIGHT / 2;
    rect.setPosition(topX, topY);
    add(rect);
    
    drawCircle(Color.yellow, getWidth()/2, getHeight()/2);
    drawCircle(Color.red, getWidth()/2, getHeight()/2 - BUFFER);
    drawCircle(Color.green, getWidth()/2, getHeight()/2 + BUFFER);
}

function drawCircle(color, x, y){
    var circle = new Circle(LIGHT_RADIUS);
    circle.setColor(color);
    circle.setPosition(x, y);
    add(circle);

}