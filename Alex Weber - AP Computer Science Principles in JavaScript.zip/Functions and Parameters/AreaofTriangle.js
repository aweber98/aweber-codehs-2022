function start(){
    var base = readInt("What is the base of the triangle? ");
    var height = readInt("What is the height of the triangle? ");
    triangleArea(base, height);
    
}

function triangleArea(first, second){
    var area = 1/2 * first * second;
    println("Result: " + area);
}