var SENTINEL = 0;

// Prints whether the entered number is even or odd
function start(){
    while(true){
        var userNum = readInt("Enter a number: ");
        var isEvenNumber = isEven(userNum);
        if(userNum == SENTINEL){
            break;
        }
    }
    
}

function isEven(x){
    if(x % 2 == 0){
        println("Even");
    }else if (x % 2 != 0){
        println("Odd");
    }

    
}