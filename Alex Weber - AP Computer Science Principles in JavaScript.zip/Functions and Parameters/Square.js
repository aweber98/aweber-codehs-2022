function start(){
    var userNum = readInt("What number do you want to square? ");
	square(userNum);
}

function square(x){
    var squareX = x * x;
    println("Result: " + squareX);
}