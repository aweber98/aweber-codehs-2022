function start(){
	var x = min(-5, -5);
	println("The min is " + x);
}

function min(first, second){
    if(first < second){
        var min = first;
    }else if (first > second){
        var min = second;
    }else if (first == second){
        var min = first;
    }
    return min;
}