function start(){
	quadruple(3);
	quadruple(7);
}

function quadruple(x){
    var quadrupledX = x*4;
    return(quadrupledX);
    println(quadrupledX);
}