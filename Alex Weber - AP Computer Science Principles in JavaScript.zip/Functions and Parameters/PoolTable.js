var POOL_BALL_RADIUS = 40;
var POOL_BALL_FONT = "30pt Arial";

function start(){
	drawPoolBall(Color.orange, 5, 100, 100);
	drawPoolBall(Color.green, 6, 50, 200);
	drawPoolBall(Color.red, 3, 150, 350);
	drawPoolBall(Color.blue, 2, 250, 140);

	// Add some more pool balls!
}


function drawPoolBall(color, num, x, y){
	var circle = new Circle(POOL_BALL_RADIUS);
	circle.setColor(color);
	circle.setPosition(x, y);
	add(circle);
	
	var txt = new Text(num, "30pt Arial");
	var circleX = circle.getX();
	var circleY = circle.getY();
    txt.setPosition(circleX - 15, circleY + 15);
    txt.setColor(Color.white);
	add(txt);
}