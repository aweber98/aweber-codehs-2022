var WHEEL_RADIUS = 25;

var TRUCK_BED_WIDTH = 250;

var TRUCK_HEIGHT = 50;

var BODY_HEIGHT = 60;

var NUM_OF_WHEELS = 4;

function start(){

    drawTruck(Color.red);



}

function drawSecondTruck(color){

    drawWheels();

    drawRims();

    drawSecondCab();

    drawSecondTruckBody(getWidth()/2-125, getHeight()/2, Color.blue);    

    drawExhaust(206);    

}

function drawTruck(color){

    drawWheels();

    drawRims();

    drawCab();

    drawTruckBody(getWidth()/2-125, getHeight()/2, Color.red);    

    drawExhaust(206);

}

function drawExhaust(x,y){

    var line = new Line(getWidth()/2, getHeight()/2, getWidth()/2, x);

    add(line);

}

function drawCab(){

    var rect = new Rectangle(55, 50);

    rect.setPosition(getWidth()/2, getHeight()/2-35);

    rect.setColor(Color.red);

    add(rect);



    var rect = new Rectangle(55, 50);

    rect.setPosition(getWidth()/2+25, getHeight()/2-23);

    rect.setColor(Color.red);

    rect.setRotation(50);

    add(rect);    



    var rect = new Rectangle(40, 25);

    rect.setPosition(getWidth()/2+10, getHeight()/2-25);

    rect.setColor(Color.gray);

    add(rect);

    

    var rect = new Rectangle(35, 30);

    rect.setPosition(getWidth()/2+33, getHeight()/2-17);

    rect.setColor(Color.gray);

    rect.setRotation(50);

    add(rect);    





}

function drawWheels(first, second){

    var circle = new Circle(WHEEL_RADIUS);

circle.setColor(Color.black);

circle.setPosition(getWidth()/2-100, getHeight()/2+60);

add(circle);



    var circle = new Circle(WHEEL_RADIUS);

circle.setColor(Color.black);

circle.setPosition(getWidth()/2-35, getHeight()/2+60);

add(circle);



    var circle = new Circle(WHEEL_RADIUS);

circle.setColor(Color.black);

circle.setPosition(getWidth()/2+100, getHeight()/2+60);

add(circle);



    var circle = new Circle(WHEEL_RADIUS);

circle.setColor(Color.black);

circle.setPosition(getWidth()/2+35, getHeight()/2+60);

add(circle);

}

function drawRims(first,second){

    var circle = new Circle(WHEEL_RADIUS-10);

circle.setColor(Color.grey);

circle.setPosition(getWidth()/2-100, getHeight()/2+60);

add(circle);    



    var circle = new Circle(WHEEL_RADIUS-10);

circle.setColor(Color.grey);

circle.setPosition(getWidth()/2-35, getHeight()/2+60);

add(circle);    



    var circle = new Circle(WHEEL_RADIUS-10);

circle.setColor(Color.grey);

circle.setPosition(getWidth()/2+100, getHeight()/2+60);

add(circle);    



    var circle = new Circle(WHEEL_RADIUS-10);

circle.setColor(Color.grey);

circle.setPosition(getWidth()/2+35, getHeight()/2+60);

add(circle);    

}

function drawTruckBody(first, second, color){

    var rect = new Rectangle(TRUCK_BED_WIDTH, TRUCK_HEIGHT);

    rect.setPosition(first, second);

    rect.setColor(Color.red);

    add(rect);



}