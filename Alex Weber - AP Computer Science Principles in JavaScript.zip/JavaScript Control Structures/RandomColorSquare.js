var SIDE_LENGTH = 100;

function start(){
    var color = Randomizer.nextColor();
	var square = new Rectangle(SIDE_LENGTH, SIDE_LENGTH);
	square.setPosition(getWidth() / 2, getHeight() / 2);
	square.setColor(color);
	add(square);
}