/* This program should declare a boolean that describes whether or
 * not you have a cat. Then you should print out an informative
 * message to the user. */
function start(){
	var userHasCat = true;
	println("Do you have a cat?: " + userHasCat);
}