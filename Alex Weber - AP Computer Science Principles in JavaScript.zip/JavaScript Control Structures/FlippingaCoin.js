function start(){
	var isHeads = Randomizer.nextBoolean();
	println("You flipped heads " + isHeads);
}