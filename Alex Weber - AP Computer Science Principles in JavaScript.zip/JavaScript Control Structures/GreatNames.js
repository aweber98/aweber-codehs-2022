// This program reads the users name
// and checks if it is equal to "Jeremy"
function start(){
	var name = readLine("Enter name: ");
	if(name == "Jeremy"){
		println("Great name.");
	}	
}