function start(){
	for(var i = 0; i <=500; i += 7){
	    println(i);
	}
}