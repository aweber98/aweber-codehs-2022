function start(){
	var points = readInt("How many points did you get? ");
	var rebounds = readInt("How many rebounds did you get? ");
	var assists = readInt("How many assists did you make? ");
	var allStar = points >= 25 || rebounds >= 10 && points >= 10 && assists >= 10;
	println("Are you an all star?: " + allStar);
}