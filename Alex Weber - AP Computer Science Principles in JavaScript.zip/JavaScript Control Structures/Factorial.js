var N = 5;

function start(){
	var MIN = 1;
    var MULT = 1;

    for(var i = MIN; i <=N; i++){
        MULT *= i;
    }   
    println("The product is " + MULT);
	
}