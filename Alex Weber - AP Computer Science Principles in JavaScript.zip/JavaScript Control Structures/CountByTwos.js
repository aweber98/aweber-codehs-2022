// This program counts to one hundred by
// twos using a for loop.
function start(){
	for(var i = 0; i <= 100; i += 2){
		println(i);
	}
}