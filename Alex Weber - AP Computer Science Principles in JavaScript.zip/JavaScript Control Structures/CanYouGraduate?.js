function start(){
	var enoughCredits = readBoolean("Do you have enough credits to graduate?: ");
	var requirements = readBoolean("Have you met the requirements to graduate?: ");
	var canGraduate = enoughCredits && requirements;
	println("Can graduate: " + canGraduate);
}