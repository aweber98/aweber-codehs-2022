function start(){
	var roll = Randomizer.nextInt(1,6);
	println("You rolled a " + roll);
}