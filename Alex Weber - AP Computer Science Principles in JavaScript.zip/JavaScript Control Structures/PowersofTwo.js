function start(){
	for (var i = 1; i <= 1000000; i *= 2){
	    println(i);
	}
}