function start(){
	var firstRoll = readInt("What did you get the first roll? ");
	var secondRoll = readInt("What did you get the second roll? ");
	var rolledDoubles = firstRoll == secondRoll;
	println("Did you roll a double?: " + rolledDoubles);
}