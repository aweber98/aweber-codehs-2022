var SIDES_ON_DICE = 6;

function start() {
	for (var i = 1; i <= 6; i++){
	    for (var a = 1; a <= 6; a++){
	        println(i + "," + a)
	    }
	}
}