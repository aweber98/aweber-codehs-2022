function start(){
    var counter = 0;
    
	while(true){
	    var x = Randomizer.nextInt(1,6);
	    var y = Randomizer.nextInt(1,6);
	    println("Rolled: " + x + "," + y);
	    counter = counter + 1;
	    
	    if(x == 1 && y == 1){
	        break;
	        
	    }
	    
	    
	}
	
	println("It took you " + counter + " rolls to get snake eyes");
}