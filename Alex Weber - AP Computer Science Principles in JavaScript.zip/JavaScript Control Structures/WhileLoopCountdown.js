function start(){
	var i = 10;
	
	while(i >= 0){
		println(i);
		i--;
	}
}