function start(){
	var meal = readLine("Enter a meal: ");
	if (meal == "breakfast"){
	    println("How about some avocado on toast?");
	}else if(meal == "lunch"){
	    println("How about some noodles?");   
	}else if(meal == "dinner"){
	    println("How about some pizza?");
	}
}