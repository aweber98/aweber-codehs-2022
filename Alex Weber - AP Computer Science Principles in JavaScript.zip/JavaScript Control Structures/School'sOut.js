function start(){
    //Write your code here
    var isWeekday = readBoolean("Is today a weekday?: ");
    var isHoliday = readBoolean("Is today a holiday?: ");
    var isNotSchoolDay = !isWeekday || isHoliday;
    println("There is no school today: " + isNotSchoolDay);
}