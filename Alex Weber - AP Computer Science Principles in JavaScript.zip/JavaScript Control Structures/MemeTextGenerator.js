function start(){
	for(var i = 0; i < 50; i++){
	    println("Takes one political science class. Knows how to solve the world’s problems.");
	}
}