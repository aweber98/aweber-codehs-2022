var MIN = readInt("What is the minimum? ");
var MAX = readInt("What is the maximum ");

function start(){
    var sum = 0;
	for(var i = MIN; i <= MAX; i++){
	    sum += i;
	}
	
	println("The sum is " + sum);
}