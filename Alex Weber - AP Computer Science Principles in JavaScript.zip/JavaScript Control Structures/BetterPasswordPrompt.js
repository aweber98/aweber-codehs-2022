var SECRET = "abc123";

function start(){
	while(true){
	    var password = readLine("Enter password: ");
	    
	    if(password != SECRET){
	        println("Sorry, that did not match. Please try again.");
	    }
	    
	    if(password == SECRET){
	        break;
	    }
	}
	println("You got it!");
}