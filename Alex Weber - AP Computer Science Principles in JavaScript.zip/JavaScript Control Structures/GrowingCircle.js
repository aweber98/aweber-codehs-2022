var circle;

function start(){
    circle = new Circle(25);
    circle.setPosition(getWidth() / 2 , getHeight() / 2);
    add(circle);
    
    keyDownMethod(keyDown);
}

function keyDown(e){
    if(e.keyCode == Keyboard.RIGHT){
        circle.setRadius(circle.getRadius() + 10);
    }
    
    if(e.keyCode == Keyboard.LEFT){
        circle.setRadius(circle.getRadius() - 10);
    }
}