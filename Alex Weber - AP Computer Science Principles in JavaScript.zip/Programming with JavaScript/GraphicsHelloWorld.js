// This program will add text that
// says "Hello world" at 100, 100.
function start(){
	var text = new Text("Hello world");
	text.setPosition(100, 100);
	add(text);
}