//Declare a constant here to represent the cost of a frisbee
    var COST_OF_FRISBEE = 15;
    
function start(){
	/* Write your code here, and get rid of this comment */
	var numFrisbees = readInt("How many frisbees would you like? ");
	var totalCost = numFrisbees * COST_OF_FRISBEE;
	println ("Total is: " + totalCost + " dollars");
	
}