/* Write a program that asks the user how far they ran (in miles)
 * and then how long it took them (in minutes), and print out
 * their speed in miles per hour. */
function start(){
	var distance = readInt("How far did you run? (in miles) ");
	var time = readInt("How long did it take you to run that distance? (in minutes) ");
	var mph = distance / time * 60 ;
	println("You ran at a speed of " + mph + " miles per hour");
}