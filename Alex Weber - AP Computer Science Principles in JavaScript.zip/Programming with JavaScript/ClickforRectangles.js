function start(){
    mouseClickMethod(drawRectangle);
}

function drawRectangle(e){
    var rectangle = new Rectangle (80,40);
    rectangle.setPosition (e.getX(), e.getY());
    var color = Randomizer.nextColor();
    rectangle.setColor(color);
    add(rectangle);
}