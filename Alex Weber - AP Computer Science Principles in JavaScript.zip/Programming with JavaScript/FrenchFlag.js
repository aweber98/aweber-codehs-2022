/* This program should draw the French flag. The
 * left third of the canvas is blue, the middle third
 * is white, and the right third is red. */
function start(){
    var rectWidth = getWidth() / 3;
    var rectHeight = getHeight();
    
	var blueRect = new Rectangle (rectWidth, rectHeight);
	blueRect.setColor(Color.blue);
	add(blueRect);
	
	
	var redRect = new Rectangle (rectWidth, rectHeight);
	redRect.setColor(Color.red);
	redRect.setPosition(267,0);
	add(redRect);
}