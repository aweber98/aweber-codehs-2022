/* This program should print out your 
 * name, and a hobby you have */
function start(){
    println("My name is Alex");
    println("I like cars");
    

}

// Sample output:
//
// My name is Jeremy
// I like to juggle
//