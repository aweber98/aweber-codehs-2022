function start(){
	var name = readLine ("What is your name? ");
	println("Name is: " + name);
	
	var droids = readInt ("How many droids are you looking for? ");
	println("Looking for: " + droids + " droids");
	
	var wookies = readInt ("How many wookies are you looking for? ");
	println("Looking for: " + wookies + " wookies");
}