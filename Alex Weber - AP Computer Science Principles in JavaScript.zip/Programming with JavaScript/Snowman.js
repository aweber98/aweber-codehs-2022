/* Constants representing the radius of the top, middle,
 * and bottom snowball. */
var BOTTOM_RADIUS = 100;
var MID_RADIUS = 60;
var TOP_RADIUS = 30;

function start(){
	/* Write your code to make the snowman here! */
	var circleHeight = getHeight() / 3 + 40;
	var centerBottom = getWidth() - 20;
	var bottomCircle = new Circle (BOTTOM_RADIUS);
	bottomCircle.setPosition (circleHeight, centerBottom);
	bottomCircle.setColor(Color.gray);
	add(bottomCircle);
	
	var middleCircle = new Circle (MID_RADIUS);
	var centerMiddle = getWidth() - 175;
	middleCircle.setPosition (circleHeight, centerMiddle);
	middleCircle.setColor(Color.gray);
	add(middleCircle);
	
	var topCircle = new Circle (TOP_RADIUS);
	var centerTop = getWidth() - 263;
	topCircle.setPosition (circleHeight, centerTop);
	topCircle.setColor (Color.gray);
	add(topCircle);
}