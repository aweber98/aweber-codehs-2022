function start(){
	var numApples = 20;
	var numOranges = 15;
	
	println("Number of apples: " + numApples);
	println("Number of Oranges: " + numOranges);
	
	numOranges = 0;
	println("Number of apples: " + numApples);
	println("Number of Oranges: " + numOranges);
}