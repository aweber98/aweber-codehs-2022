function start(){
	var line = ["Sam", "Lisa", "Laurie", "Bob", "Ryan"];
	var line2 = ["Tony", "Lisa", "Laurie", "Karen"];
	// Your code goes here
	var x = indexOf(line, "Bob");
	var y = indexOf(line2, "Bob");
	if (x == true){
	    println("Bob is in the first line.");
	}else{
	    println("Bob is not in the first line.");
	}
	if (y == true){
	    println("Bob is in the second line.");
	}else{
	    println("Bob is not in the second line.");
	}
}
function indexOf(arr, str){
    for(var i = 0; i < arr.length; i++){
        var cur = arr[i];
        if (cur == str){
          return(true); 
        }
    }
    return(false);
    
   
}