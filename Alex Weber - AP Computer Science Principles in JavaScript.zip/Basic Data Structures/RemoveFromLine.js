function start(){
    var line = ["Sam", "Lisa", "Laurie", "Bob", "Ryan"];
    for(var i = 0; i < line.length; i++){
        if(i + 1 == line.length){
            println(line[i]);
        }else{
            print(line[i] + ", ");
        }
    }
    var elim = line.remove(1);
    var elim2 = line.remove(0);
    for(var i = 0; i < line.length; i++){
        if(i + 1 == line.length){
            print(line[i]);
        }else{
            print(line[i] + ", ");
        }
    }
}