function start(){
	// Write your code here
	var arr = [1,2,3,4];
    var doubled = doubleList(arr);
    println(doubled);
}

function doubleList(arr){
    
    var x = arr;
    var length = x.length;
    var y = [];
    for (var i = 0; i < length; i++){
        var cur = arr[i]
        y.push(cur);
        y.push(cur);
    }
    
    return y;
}