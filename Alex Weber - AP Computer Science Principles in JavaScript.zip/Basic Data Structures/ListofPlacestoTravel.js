function start(){
	var travelList = ["France", "Italy", "India", "Australia"];
	println(travelList[2]);
}