function start(){
	// Write your code here
	var itinerary = ["San Francisco", "New York", "Chicago", "Honolulu"];
	
	
	for (var i = 0; i < itinerary.length; i++){
	    var cur = itinerary[i]
	    print(cur);
	    print(" -> ");
	}
	
}