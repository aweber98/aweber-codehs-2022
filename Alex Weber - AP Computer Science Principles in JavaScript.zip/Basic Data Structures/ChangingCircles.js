var NUM_CIRCLES = 15;
var MIN_RADIUS = 10;
var MAX_RADIUS = 40;
var DELAY = 500;

var circles = [];

function start(){
	// Your code here
	createCircles(NUM_CIRCLES);
	setTimer(changeColors, DELAY);
}

function changeColors(){
    var color = Randomizer.nextColor();
    for(var i = 0; i < circles.length; i++){
        circles[i].setColor(color);
    }
}

function createRandomCircle(){
    var radius = Randomizer.nextInt(MIN_RADIUS, MAX_RADIUS);
    var x = Randomizer.nextInt(radius, getWidth() - radius);
    var y = Randomizer.nextInt(radius, getHeight() - radius);
    var circle = new Circle(radius);
    circle.setPosition(x,y);
    add(circle);
    return circle;
}

function createCircles(NUM_CIRCLES){
    for(var i = 0; i < NUM_CIRCLES; i++){
        circles.push(createRandomCircle());
    }
}