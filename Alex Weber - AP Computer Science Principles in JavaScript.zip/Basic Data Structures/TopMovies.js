function start(){
	// Write your code here
	var movieList = ["Movie1","Movie2","Movie3","Movie4"];
	println(movieList[0]);
	
	movieList[0] = "Star Wars";
	println(movieList[0]);
}