function start(){
	// Write your code here
	var arr = [1,2,3,4,5,6];
    var evens = onlyEvens(arr);
    println(evens);
}

function onlyEvens(arr){
    var x = [];
    
    for(var i = 0; i < arr.length; i++){
        var cur = arr[i];
        if (cur % 2 == 0) {
            x.push(cur);
        }
    }
    
    return x;
}