function start(){
	// Write your code here
	var arr = [1,2,3,4];
    var reversed = reverseList(arr);
    println(reversed);
}

function reverseList(arr){
    var x = [];
    for(var i = arr.length; i >= 0; i--){
        var cur = arr[i];
        x.push(cur);
    }
    return x;
}