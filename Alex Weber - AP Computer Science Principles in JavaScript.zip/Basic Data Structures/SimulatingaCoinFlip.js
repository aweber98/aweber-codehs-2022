var NUM_FLIPS = 10;
var RANDOM = Randomizer.nextBoolean();    
var HEADS = "Heads";
var TAILS = "Tails";

function start(){

    var flips = flipCoins();
    printArray(flips);
    countHeadsAndTails(flips);

}


function flipCoins(){
    var flips = [];
    for(var i = 0; i < NUM_FLIPS; i++){
        if(Randomizer.nextBoolean()){
            flips.push(HEADS);
        }else{
            flips.push(TAILS);
        }
    }
    return flips;

}

function printArray(arr){
    for(var i = 0; i < arr.length; i++){
        println("Flip Number " + (i+1) + ": " + arr[i]);
    }

}

function countHeadsAndTails(flips){
    var countOne = 0;
    var countTwo = 0;
    for(var i = 0; i < flips.length; i++){
        if(flips[i] == HEADS){
            countOne+=1;
        }else{
            countTwo+=1; 
        }
    }
    println("Number of Heads: " + countOne);
    println("Number of Tails: " + countTwo);

}