function start(){
	var numList = [2,3,5,7,11];
	println(numList[0]);
	println(numList[2]);
	println(numList[4]);
	
}