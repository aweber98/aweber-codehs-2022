function start(){
	// Write your code here
	var arr = [];
	
	arr.push(3);
	arr.push("hello");
	arr.push(false);
	
	println(arr[0]);
	println(arr[1]);
	println(arr[2]);
	
	var f = arr.pop();
	var h = arr.pop();
	
	println(arr[0]);
	println(arr[1]);
	println(arr[2]);
	
}