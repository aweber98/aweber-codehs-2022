// These are constant variables that can and will be used by any function in the program.
var QUESTION = 1;
var NUMS = [];
var NUMQ1 = 0;
var NUMQ2 = 0;
var NUMQ3 = 0;
// The last 3 variables will take the values the user entered on the first, second, and third questions, respectively.

function start(){
   // The start function calls the main input functions of the program.
   makeCalculator();
   mouseMoveMethod(onMouseMove);
   keyDownMethod(nextFunction);
    
}

function onMouseMove(e) {
    // This function is tracking mouse movements. When the user clicks, 
    // it determines where the user has clicked by using the parameter "e", 
    // to call one of the number functions.
    // When a one of the number functions are called, it takes that number and adds it to
    // the array "NUMS".
	var mouseX = (e.getX());
	var mouseY = (e.getY());
	
	
	if(mouseX < 134 && mouseY < 246 && mouseY > 150){
	    var uno = mouseClickMethod(one);
	}else if(mouseX < 267 && mouseX > 134 && mouseY < 246 && mouseY > 150){
	    var dos = mouseClickMethod(two);
	}else if(mouseX < 401 && mouseX > 267 && mouseY > 150 && mouseY < 246){
	    var tres = mouseClickMethod(three);
	}else if(mouseX < 134 && mouseY < 342 && mouseY > 246){
	    var cuatro = mouseClickMethod(four);
	}else if(mouseX < 267 && mouseX > 134 && mouseY < 342 && mouseY > 246){
	    var cinco = mouseClickMethod(five);
	}else if(mouseX > 267 && mouseX < 401 && mouseY < 342 && mouseY > 246){
	    var seis = mouseClickMethod(six);
	}else if(mouseX < 134 && mouseY < 438 && mouseY > 342){
	    var siete = mouseClickMethod(seven);
	}else if(mouseX < 267 && mouseX > 134 && mouseY < 438 && mouseY > 342){
	    var ocho = mouseClickMethod(eight);
	}else if(mouseX > 267 && mouseX < 401 && mouseY < 438 && mouseY > 342){
	    var nueve = mouseClickMethod(nine);
	}else if(mouseY > 438 && mouseY < 481){
	    var cero = mouseClickMethod(zero);
	}
	
	
}

function makeCalculator(){
   // This function makes the calculator graphics, along with adding the first question to the screen.
   
   println("Please press Enter to proceed to the next question.");
   
    var one = new Rectangle(getWidth() / 3, getHeight() / 5);
    one.setPosition(1, 150)
    one.setBorderColor(Color.red);
    one.setBorderWidth(3);
    add(one);
    
    var oneT = new Text("1", "30pt Arial");
    var oneTx = one.getWidth() / 2 - 10;
    var oneTy = one.getHeight() * 2 + 23;
    oneT.setPosition(oneTx, oneTy);
    oneT.setColor(Color.white);
    add(oneT);
    
    var two = new Rectangle(getWidth() / 3, getHeight() / 5);
    two.setPosition(134, 150);
    two.setBorderColor(Color.red);
    two.setBorderWidth(3);
    add(two);
    
    var twoT = new Text("2", "30pt Arial");
    var twoTx = two.getX() / 2 + two.getX() - 15;
    var twoTy = two.getY() + two.getY() / 2 - 10;
    twoT.setPosition(twoTx, twoTy);
    twoT.setColor(Color.white);
    add(twoT);
    
    var three = new Rectangle(getWidth() / 3, getHeight() / 5);
    three.setPosition(267, 150);
    three.setBorderColor(Color.red);
    three.setBorderWidth(3);
    add(three);
    
    var threeT = new Text("3", "30pt Arial");
    var threeTx = three.getX() + three.getX() / 5;
    var threeTy = three.getY() + three.getY() / 2 - 10;
    threeT.setPosition(threeTx, threeTy);
    threeT.setColor(Color.white);
    add(threeT);
    
   var four = new Rectangle(getWidth() / 3, getHeight() / 5);
    four.setPosition(1, 246);
    four.setBorderColor(Color.red);
    four.setBorderWidth(3);
    add(four);
    
    var fourT = new Text("4", "30pt Arial");
    var fourTx = four.getWidth() / 2 - 10;
    var fourTy = four.getY() + four.getY() / 4;
    fourT.setPosition(fourTx, fourTy);
    fourT.setColor(Color.white);
    add(fourT);
    
    var five = new Rectangle(getWidth() / 3, getHeight() / 5);
    five.setPosition(134, 246);
    five.setBorderColor(Color.red);
    five.setBorderWidth(3);
    add(five);
    
    var fiveT = new Text("5", "30pt Arial");
    var fiveTx = five.getX() / 2 + five.getX() - 15;
    var fiveTy = five.getY() + five.getY() / 4;
    fiveT.setPosition(fiveTx, fiveTy);
    fiveT.setColor(Color.white);
    add(fiveT);
    
    var six = new Rectangle(getWidth() / 3, getHeight() / 5);
    six.setPosition(267, 246);
    six.setBorderColor(Color.red);
    six.setBorderWidth(3);
    add(six);
    
    var sixT = new Text("6", "30pt Arial");
    var sixTx = six.getX() + six.getX() / 5;
    var sixTy = six.getY() + six.getY() / 4;
    sixT.setPosition(sixTx, sixTy);
    sixT.setColor(Color.white);
    add(sixT);
    
    var seven = new Rectangle(getWidth() / 3, getHeight() / 5);
    seven.setPosition(1, 342);
    seven.setBorderColor(Color.red);
    seven.setBorderWidth(3);
    add(seven);
    
    var sevenT = new Text("7", "30pt Arial");
    var sevenTx = seven.getWidth() / 2 - 10;
    var sevenTy = seven.getY() + seven.getY() / 5 - 3;
    sevenT.setPosition(sevenTx, sevenTy);
    sevenT.setColor(Color.white);
    add(sevenT);
    
    var eight = new Rectangle(getWidth() / 3, getHeight() / 5);
    eight.setPosition(134, 342);
    eight.setBorderColor(Color.red);
    eight.setBorderWidth(3);
    add(eight);
    
    var eightT = new Text("8", "30pt Arial");
    var eightTx = eight.getX() / 2 + eight.getX() - 15;
    var eightTy = eight.getY() + eight.getY() / 4 - 21;
    eightT.setPosition(eightTx, eightTy);
    eightT.setColor(Color.white);
    add(eightT);
    
    var nine = new Rectangle(getWidth() / 3, getHeight() / 5);
    nine.setPosition(267, 342);
    nine.setBorderColor(Color.red);
    nine.setBorderWidth(3);
    add(nine);
    
    var nineT = new Text("9", "30pt Arial");
    var nineTx = nine.getX() + nine.getX() / 5;
    var nineTy = nine.getY() + nine.getY() / 4 - 21;
    nineT.setPosition(nineTx, nineTy);
    nineT.setColor(Color.white);
    add(nineT);
    
    var zero = new Rectangle(getWidth(), getHeight() / 12);
    zero.setPosition(1, 438);
    zero.setBorderColor(Color.red);
    zero.setBorderWidth(3);
    add(zero);
    
    var zeroT = new Text("0", "30pt Arial");
    var zeroTx = getWidth() / 2 - 15;
    var zeroTy = zero.getY() + 35;
    zeroT.setPosition(zeroTx, zeroTy);
    zeroT.setColor(Color.white);
    add(zeroT);
    
    
    var q1 = new Text ("How many school days have you had this year?", "12pt Arial");
    q1.setPosition(getWidth() / 7 - 30, getHeight() / 7 - 25);
    q1.setColor(Color.black);
    add(q1);
    
    
    
}

function one(){
    // This function adds a big "1" to the screen and pushes the number 1 to the array "NUMS".
    var one = new Text("1", "40pt Arial");
    one.setPosition(getWidth() / 2 - 190, getHeight() / 4);
    one.setColor(Color.red);
    add(one);
    NUMS.push(1);
}

function two(){
    // This function adds a big "2" to the screen and pushes the number 2 to the array "NUMS".
    var two = new Text("2", "40pt Arial");
    two.setPosition(getWidth() / 2 - 160, getHeight() / 4);
    two.setColor(Color.red);
    add(two);
    NUMS.push(2);
}

function three(){
    // This function adds a big "3" to the screen and pushes the number 3 to the array "NUMS".
    var three = new Text("3", "40pt Arial");
    three.setPosition(getWidth() / 2 - 130, getHeight() / 4);
    three.setColor(Color.red);
    add(three);
    NUMS.push(3);
}

function four(){
    // This function adds a big "4" to the screen and pushes the number 4 to the array "NUMS".
    var four = new Text("4", "40pt Arial");
    four.setPosition(getWidth() / 2 - 100, getHeight() / 4);
    four.setColor(Color.red);
    add(four);
    NUMS.push(4);
}

function five(){
    // This function adds a big "5" to the screen and pushes the number 5 to the array "NUMS".
    var five = new Text("5", "40pt Arial");
    five.setPosition(getWidth() / 2 - 70, getHeight() / 4);
    five.setColor(Color.red);
    add(five);
    NUMS.push(5);
}

function six(){
    // This function adds a big "6" to the screen and pushes the number 6 to the array "NUMS".
    var six = new Text("6", "40pt Arial");
    six.setPosition(getWidth() / 2 - 40, getHeight() / 4);
    six.setColor(Color.red);
    add(six);
    NUMS.push(6);
}

function seven(){
    // This function adds a big "7" to the screen and pushes the number 7 to the array "NUMS".
    var seven = new Text("7", "40pt Arial");
    seven.setPosition(getWidth() / 2 - 10, getHeight() / 4);
    seven.setColor(Color.red);
    add(seven);
    NUMS.push(7);
}

function eight(){
    // This function adds a big "8" to the screen and pushes the number 8 to the array "NUMS".
    var eight = new Text("8", "40pt Arial");
    eight.setPosition(getWidth() / 2 + 20, getHeight() / 4);
    eight.setColor(Color.red);
    add(eight);
    NUMS.push(8);
}

function nine(){
    // This function adds a big "9" to the screen and pushes the number 9 to the array "NUMS".
    var nine = new Text("9", "40pt Arial");
    nine.setPosition(getWidth() / 2 + 50, getHeight() / 4);
    nine.setColor(Color.red);
    add(nine);
    NUMS.push(9);
}

function zero(){
    // This function adds a big "0" to the screen and pushes the number 0 to the array "NUMS".
    var zero = new Text("0", "40pt Arial");
    zero.setPosition(getWidth() / 2 + 80, getHeight() / 4);
    zero.setColor(Color.red);
    add(zero);
    NUMS.push(0);
}

function nextFunction(e){
    // This function allows the user to proceed to the next question when they press Enter (taken by the parameter "e").
    // This function also clears the calculator and stores the values that the user entered, and then
    // assigns those values to one of the constant variables "NUMQ1", "NUMQ2", and "NUMQ3", depending on.
    // which question they are on.
    if(e.keyCode == Keyboard.ENTER){
        clearCalc();
        if(QUESTION == 1){
            var input1 = (printNums());
            NUMQ1 += input1;
            println("You have had " + input1 + " school days this year.");
            question2();
        }else if(QUESTION == 2){
            var input2 = (printNums());
            NUMQ2 += input2;
            println("You have had " + input2 + " snow days this year.");
            question3();
        }else if(QUESTION == 3){
            var input3 = (printNums());
            NUMQ3 += input3;
            println("There will be " + input3 + " inches of snow tomorrow.");
            calculateSnowDays();
        }
        QUESTION++
    }
}

function printNums(){
    // This function takes all of the numbers in the array "NUMS" and combines them into one number, assigns that number to
    // the variable "numsToString", then empties the array. The value contained in "numsToString" is then returned to the variable
    // in which the function "printNums" was called.
    // For example, if the array "NUMS" was assigned the values "2", "3", and "0", this function would take those numbers and
    // turn them into the number 230, and then return that value to the variable that called this function.
    var numsToString = NUMS.join("");
    while(NUMS.length > 0){
        NUMS.pop();
    }
    return(numsToString);
}

function clearCalc(){
    // This function "clears" the calulator by covering the previous question and numbers entered with a white rectangle.
    var cover = new Rectangle(370, 110);
    cover.setPosition(getWidth() / 7 - 45, getHeight() / 7 - 50);
    cover.setColor(Color.white);
    add(cover);
}

function question2(){
    // This function adds the second question to the screen.
    var q2 = new Text ("How many snow days have you had this year?", "12pt Arial");
    q2.setPosition(getWidth() / 7 - 30, getHeight() / 7 - 25);
    q2.setColor(Color.black);
    add(q2);
}

function question3(){
    // This function adds the third question to the screen.
    var q3 = new Text ("How much snow will there be tomorrow? (in inches)", "12pt Arial");
    q3.setPosition(getWidth() / 7 - 40, getHeight() / 7 - 25);
    q3.setColor(Color.black);
    add(q3);
}

function calculateSnowDays(){
    // This function is a simple algorithm that calculates the percentage chance of the user having a
    // snow day tomorrow.
    // It does this by taking the amount of school days the user has, the amount of snow days the user
    // has had so far, and how many inches of snow is predicted to fall tomorrow, and then determining
    // how much of a chance there will be of having a snow day tomorrow.
    // This function also adds the result text to the screen.
    var resultA = [];
    println("That means...");
    
    var txt1 = new Text ("There is a", "14pt Arial");
    txt1.setPosition(getWidth() / 2 - 50, getHeight() / 7 - 40);
    txt1.setColor(Color.black);
    add(txt1);
    
    var txt2 = new Text("chance of having a snow day tomorrow", "14pt Arial");
    txt2.setPosition(getWidth() / 5 - 40, getHeight() / 3 - 30);
    txt2.setColor(Color.black);
    add(txt2);
    
    if(NUMQ1 >= 180){
        if(NUMQ2 <= 4){
            if(NUMQ3 >= 6){
                resultA.push("100%");
            }else{
                resultA.push("50%");
            }
        }else{
            if(NUMQ3 >= 8){
                resultA.push("100%");
            }else if(NUMQ3 < 8 && NUMQ3 >= 5){
                resultA.push("25%");
            }else if(NUMQ3 < 5){
                resultA.push("0%");
            }
        }
    }else{
        if(NUMQ2 <= 3){
            if(NUMQ3 >= 7){
                resultA.push("100%");
            }else if(NUMQ3 < 7 && NUMQ3 >= 4){
                resultA.push("50%");
            }else{
                resultA.push("0%");
            }
        }else{
            if(NUMQ3 >= 7){
                resultA.push("100%");
            }else if(NUMQ3 < 7 && NUMQ3 >= 5){
                resultA.push("25%");    
            }else{
                resultA.push("0%")
            }
        }
    }
    
    var result = resultA.join("");
    
    var resultTxt = new Text(result, "40pt Arial");
    resultTxt.setPosition(getWidth() / 3, getHeight() / 5);
    resultTxt.setColor(Color.red);
    add(resultTxt);
    
    println("There is a " + result + " chance of having a snow day tomorrow.");
}